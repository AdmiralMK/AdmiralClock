/*
 * OlyaClock v15 — ESP32 + GC9A01 (240x240)
 * Пины: RST=G4, CS=G19, DC=G16, SDA=G23, SCL=G18
 *
 * Изменения v15:
 *  - переключение цветовых тем по кнопке BOOT (GPIO0)
 *  - 4 темы: Синий / Чёрный / Гранат / Зелёный
 *  - полный RGB332 в дизеринге (для красного/зелёного каналов)
 */

#pragma GCC diagnostic ignored "-Wcpp"

#include "secrets.h"
#include <Arduino.h>
#include <TFT_eSPI.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <time.h>
#include <sys/time.h>
#include <math.h>

#include "FontsVLW/DelaGothicOne18.h"
#include "FontsVLW/Condiment24.h"
#include "FontsVLW/RobotoCondensed14.h"
#include "FontsVLW/IBMPlexMonoSemiBold10.h"

TFT_eSPI    tft     = TFT_eSPI();
TFT_eSprite bgSpr   = TFT_eSprite(&tft);
TFT_eSprite workSpr = TFT_eSprite(&tft);

#define CX 120
#define CY 120
#define SCR_W 240
#define SCR_H 240
#define SPR_BYTES (SCR_W * SCR_H)

// ─── ШРИФТЫ ───
#define FONT_NUMBERS    DelaGothicOne18
#define FONT_TITLE      Condiment24
#define FONT_DATE       RobotoCondensed14
#define FONT_STATUS     IBMPlexMonoSemiBold10
#define FONT_INFO       IBMPlexMonoSemiBold10

// ─── КНОПКА BOOT ───
#define BTN_BOOT_PIN         0
const unsigned long BTN_DEBOUNCE_MS = 300;

// ─────────────────────────────────────────────
// ТЕМЫ
// ─────────────────────────────────────────────
struct Theme {
  const char* name;
  uint8_t gradCR, gradCG, gradCB;   // цвет в центре градиента
  uint8_t gradER, gradEG, gradEB;   // цвет у края
  uint8_t ringR, ringG, ringB;      // внешнее кольцо
  uint8_t tickR, tickG, tickB;      // минутные засечки
};

const Theme THEMES[] = {
  //          название  центр R,G,B    край R,G,B     кольцо R,G,B   засечки R,G,B
  { "Синий",    0,  90, 210,    0,  8,  45,    50, 100, 180,   120, 160, 220 },
  { "Чёрный",  40,  40,  55,    5,  5,  12,    90,  90, 110,   110, 110, 130 },
  { "Гранат", 120,  20,  30,   30,  0,   5,   160,  50,  60,   200, 120, 120 },
  { "Зелёный", 20, 100,  40,    0, 20,  10,    60, 150,  90,   120, 200, 140 },
};
const int THEME_COUNT = sizeof(THEMES) / sizeof(THEMES[0]);
int g_currentTheme = 0;

// Текущие цвета градиента (используются в drawGradientDithered и gradientColorAt)
uint8_t g_gradCR = 0,  g_gradCG = 90, g_gradCB = 210;
uint8_t g_gradER = 0,  g_gradEG = 8,  g_gradEB = 45;

// ─── ИКОНКА ЛУНЫ ───
const bool MOON_ENABLED          = true;
const int  MOON_DIST_FROM_CENTER = 48;
const int  MOON_ICON_SIZE        = 20;
const int  MOON_SHADOW_DX        = 2;
const int  MOON_SHADOW_DY        = 2;
const unsigned long MOON_PULSE_MS = 3000;

// ─── НАЗВАНИЕ ───
const char* CLOCK_TITLE = "Admiral";
const int TITLE_X = CX;
const int TITLE_Y = 85;
const bool TITLE_SHADOW_ENABLED = true;
const int  TITLE_SHADOW_DX      = 1;
const int  TITLE_SHADOW_DY      = 1;

// ─── СТАРТОВОЕ ВРЕМЯ ───
const int DEFAULT_HOUR = 12;
const int DEFAULT_MIN  = 0;

// ─── ПРОКРУТКА ───
const unsigned long SPIN_DURATION_MS = 1800;
const int SPIN_HOUR_TURNS = 2;
const int SPIN_MIN_TURNS  = 1;
const int SPIN_SEC_TURNS  = 3;
const unsigned long WIFI_TIMEOUT_MS = 15000;
const unsigned long NTP_TIMEOUT_MS  = 30000;

// ─── API ───
const char* OWM_API_KEY = SECRET_OWM_API_KEY;
const char* OWM_CITY    = "Ufa,RU";
const char* FX_API_KEY  = SECRET_FX_API_KEY;
const char* FX_BASE     = "RUB";
const char* FX_TARGET1  = "USD";
const char* FX_TARGET2  = "EUR";

const unsigned long WEATHER_UPDATE_MS = 15UL * 60UL * 1000UL;
const unsigned long FX_UPDATE_MS      = 60UL * 60UL * 1000UL;

float   g_tempC        = 0.0f;
char    g_weatherDesc[48] = {0};
float   g_usdRub       = 0.0f;
float   g_eurRub       = 0.0f;
bool    g_weatherValid = false;
bool    g_fxValid      = false;
time_t  g_sunriseUnix  = 0;
time_t  g_sunsetUnix   = 0;
bool    g_sunValid     = false;
unsigned long g_lastWeatherMs = 0;
unsigned long g_lastFxMs      = 0;

// ─── ГЕОМЕТРИЯ ───
const int SCREEN_MARGIN       = 8;
const int TICK_HOUR_LENGTH    = 13;
const int TICK_MIN_LENGTH     = 5;
const int NUMBERS_RADIUS_BASE = 82;
const int NUMBERS_RADIUS_FIX  = 2;

const int R_OUTER      = (SCR_W / 2) - SCREEN_MARGIN;
const int R_HOUR_INNER = R_OUTER - TICK_HOUR_LENGTH;
const int R_MIN_INNER  = R_OUTER - TICK_MIN_LENGTH;
const int NUMBERS_R    = NUMBERS_RADIUS_BASE + NUMBERS_RADIUS_FIX;

// ─── КОЛЬЦО ───
const bool RING_ENABLED   = true;
const int  RING_OFFSET    = 2;
const int  RING_THICKNESS = 2;

// ─── ТЕНЬ ЦИФР ───
const bool NUMBER_SHADOW_ENABLED = true;
const int  NUMBER_SHADOW_DX      = 2;
const int  NUMBER_SHADOW_DY      = 2;

// ─── БЛИК СТУПИЦЫ ───
const bool HUB_HIGHLIGHT_ENABLED = true;
const int  HUB_HL_DX = -1;
const int  HUB_HL_DY = -1;
const int  HUB_HL_R  = 1;

// ─── ДАТА ───
const int DATE_X = 163;
const int DATE_Y = 114;
const int DATE_W = 22;
const int DATE_H = 14;
const int DATE_FRAME_OUTER = 3;
const int DATE_FRAME_INNER = 2;

// ─── ИНФО-ОБЛАСТЬ ───
const int INFO_X    = CX;
const int INFO_STEP = 12;
const int STATUS_Y  = 156;
const int WEATHER_Y = STATUS_Y  + INFO_STEP;
const int FX_Y      = WEATHER_Y + INFO_STEP;
const int SUN_Y     = FX_Y      + INFO_STEP;

const bool INFO_SHADOW_ENABLED = true;
const int  INFO_SHADOW_DX      = 1;
const int  INFO_SHADOW_DY      = 1;

const bool SHOW_DATE_IN_STATUS = true;

const char* WEEKDAYS_RU[7] = {
  "Воскресенье", "Понедельник", "Вторник",
  "Среда", "Четверг", "Пятница", "Суббота"
};

const char* WIFI_SSID     = SECRET_WIFI_SSID;
const char* WIFI_PASSWORD = SECRET_WIFI_PASSWORD;
const char* TZ_INFO       = "UTC-5";
const char* NTP_SERVER    = "pool.ntp.org";

// ─── ФАЗЫ ───
enum Phase { PHASE_WIFI, PHASE_SYNC, PHASE_NTP_FAIL, PHASE_SPIN, PHASE_RUN };
Phase         phase      = PHASE_WIFI;
unsigned long phaseStart = 0;
unsigned long spinStart  = 0;
float         spinStartH = 0;
float         spinStartM = 0;
float         spinStartS = 0;

// ─── ЦВЕТА ───
uint16_t C_HAND_RED, C_HAND_DARK, C_HAND_HILITE, C_SHADOW;
uint16_t C_TICK_MIN, C_DATE_BORDER, C_TITLE, C_STATUS, C_RING;
uint16_t C_STATUS_BG;
uint16_t C_DATE_INSET_DARK, C_DATE_INSET_LIGHT;
uint16_t C_INFO, C_INFO_BG;
uint16_t C_MOON_BASE, C_MOON_DARK, C_MOON_CRATER, C_MOON_HIGHLIGHT, C_MOON_SHADOW;

void initColors() {
  C_HAND_RED     = tft.color565(220, 30, 30);
  C_HAND_DARK    = tft.color565(140, 10, 10);
  C_HAND_HILITE  = tft.color565(255, 140, 140);
  C_SHADOW       = tft.color565(5, 5, 25);
  C_DATE_BORDER  = tft.color565(200, 205, 220);
  C_TITLE        = tft.color565(255, 200, 80);
  C_STATUS       = tft.color565(220, 230, 255);
  C_DATE_INSET_DARK  = tft.color565(130, 145, 180);
  C_DATE_INSET_LIGHT = tft.color565(245, 248, 255);
  C_INFO         = tft.color565(230, 240, 255);
  C_MOON_BASE      = tft.color565(255, 240, 230);
  C_MOON_DARK      = tft.color565(60,  70,  110);
  C_MOON_CRATER    = tft.color565(220, 200, 140);
  C_MOON_HIGHLIGHT = tft.color565(255, 255, 230);
  C_MOON_SHADOW    = tft.color565(40,   50,   150);

  // C_RING, C_TICK_MIN, C_STATUS_BG, C_INFO_BG — задаются в applyTheme()
}

// ─── УГЛЫ ───
static inline float angleHour(int h, int m, int s, float sub) {
  return (h % 12) * 30.0f + m * 0.5f + (s + sub) * (0.5f / 60.0f);
}
static inline float angleMin(int m, int s, float sub) {
  return m * 6.0f + (s + sub) * 0.1f;
}
static inline float angleSec(int s, float sub) {
  return (s + sub) * 6.0f;
}
static inline bool timeIsValid() {
  return time(nullptr) > 1700000000UL;
}

// ─────────────────────────────────────────────
// Цвет градиента в точке (x, y)
// ─────────────────────────────────────────────
static inline uint16_t gradientColorAt(int x, int y) {
  int dx = x - CX, dy = y - CY;
  int r2 = dx*dx + dy*dy;
  float t = (r2 > 120*120) ? 1.0f : sqrtf((float)r2) / 120.0f;
  int R = (int)(g_gradCR * (1.0f - t) + g_gradER * t);
  int G = (int)(g_gradCG * (1.0f - t) + g_gradEG * t);
  int B = (int)(g_gradCB * (1.0f - t) + g_gradEB * t);
  return tft.color565(R, G, B);
}

// ─────────────────────────────────────────────
// ГРАДИЕНТ (полный RGB332: RRRGGGBB)
// ─────────────────────────────────────────────
void drawGradientDithered(TFT_eSprite &s) {
  uint8_t* buf = (uint8_t*)s.getPointer();
  if (!buf) return;
  static const uint8_t bayer[4][4] = {
    { 0,  8,  2, 10}, {12,  4, 14,  6},
    { 3, 11,  1,  9}, {15,  7, 13,  5}
  };
  for (int y = 0; y < SCR_H; y++) {
    int dy = y - CY, dy2 = dy * dy;
    uint8_t* row = buf + y * SCR_W;
    for (int x = 0; x < SCR_W; x++) {
      int dx = x - CX;
      int r2 = dx*dx + dy2;
      if (r2 > 120*120) { row[x] = 0; continue; }
      float t  = sqrtf((float)r2) / 120.0f;
      float Rf = g_gradCR * (1.0f - t) + g_gradER * t;
      float Gf = g_gradCG * (1.0f - t) + g_gradEG * t;
      float Bf = g_gradCB * (1.0f - t) + g_gradEB * t;
      int bv = bayer[y & 3][x & 3];

      float rS = (Rf / 255.0f) * 7.0f;  int rI = (int)rS;
      if ((rS - rI) * 16.0f > bv) rI++;
      if (rI < 0) rI = 0; if (rI > 7) rI = 7;

      float gS = (Gf / 255.0f) * 7.0f;  int gI = (int)gS;
      if ((gS - gI) * 16.0f > bv) gI++;
      if (gI < 0) gI = 0; if (gI > 7) gI = 7;

      float bS = (Bf / 255.0f) * 3.0f;  int bI = (int)bS;
      if ((bS - bI) * 16.0f > bv) bI++;
      if (bI < 0) bI = 0; if (bI > 3) bI = 3;

      // RGB332: RRRGGGBB
      row[x] = (rI << 5) | (gI << 2) | bI;
    }
  }
}

// ─── СТАТИКА ───
void drawTicks(TFT_eSprite &s) {
  for (int m = 0; m < 60; m++) {
    float angle = (m * 6.0f - 90.0f) * DEG_TO_RAD;
    bool isHour = (m % 5 == 0);
    int rOuter = R_OUTER;
    int rInner = isHour ? R_HOUR_INNER : R_MIN_INNER;
    int x1 = CX + (int)(cosf(angle) * rInner);
    int y1 = CY + (int)(sinf(angle) * rInner);
    int x2 = CX + (int)(cosf(angle) * rOuter);
    int y2 = CY + (int)(sinf(angle) * rOuter);
    uint16_t col = isHour ? TFT_WHITE : C_TICK_MIN;
    s.drawLine(x1, y1, x2, y2, col);
    if (isHour) {
      int x1b = CX + (int)(cosf(angle) * (rInner - 2));
      int y1b = CY + (int)(sinf(angle) * (rInner - 2));
      s.drawLine(x1b, y1b, x2, y2, col);
    }
  }
}

void drawRing(TFT_eSprite &s) {
  if (!RING_ENABLED) return;
  int r = R_OUTER + RING_OFFSET;
  s.drawCircle(CX, CY, r, C_RING);
  if (RING_THICKNESS >= 2) s.drawCircle(CX, CY, r + 1, C_RING);
}

void drawNumbers(TFT_eSprite &s) {
  s.setTextDatum(MC_DATUM);
  s.loadFont(FONT_NUMBERS);
  for (int h = 1; h <= 12; h++) {
    float angle = (h * 30.0f - 90.0f) * DEG_TO_RAD;
    int x = CX + (int)(cosf(angle) * NUMBERS_R);
    int y = CY + (int)(sinf(angle) * NUMBERS_R);
    if (NUMBER_SHADOW_ENABLED) {
      int sx = x + NUMBER_SHADOW_DX, sy = y + NUMBER_SHADOW_DY;
      s.setTextColor(C_SHADOW, gradientColorAt(sx, sy));
      s.drawString(String(h), sx, sy);
    }
    s.setTextColor(TFT_WHITE, gradientColorAt(x, y));
    s.drawString(String(h), x, y);
  }
  s.unloadFont();
}

void drawTitle(TFT_eSprite &s) {
  s.loadFont(FONT_TITLE);
  s.setTextDatum(MC_DATUM);
  if (TITLE_SHADOW_ENABLED) {
    int sx = TITLE_X + TITLE_SHADOW_DX, sy = TITLE_Y + TITLE_SHADOW_DY;
    s.setTextColor(C_SHADOW, gradientColorAt(sx, sy));
    s.drawString(CLOCK_TITLE, sx, sy);
  }
  s.setTextColor(C_TITLE, gradientColorAt(TITLE_X, TITLE_Y));
  s.drawString(CLOCK_TITLE, TITLE_X, TITLE_Y);
  s.unloadFont();
}

void drawDateFrame(TFT_eSprite &s) {
  const int ox = DATE_FRAME_OUTER, ix = DATE_FRAME_INNER;
  s.drawRect(DATE_X - ox, DATE_Y - ox, DATE_W + ox*2, DATE_H + ox*2, C_DATE_BORDER);
  s.drawRect(DATE_X - ix, DATE_Y - ix, DATE_W + ix*2, DATE_H + ix*2, C_DATE_INSET_DARK);
  s.fillRect(DATE_X, DATE_Y, DATE_W, DATE_H, TFT_WHITE);
  s.drawLine(DATE_X, DATE_Y, DATE_X + DATE_W - 1, DATE_Y, C_DATE_INSET_DARK);
  s.drawLine(DATE_X, DATE_Y, DATE_X, DATE_Y + DATE_H - 1, C_DATE_INSET_DARK);
  s.drawLine(DATE_X, DATE_Y + DATE_H - 1, DATE_X + DATE_W - 1, DATE_Y + DATE_H - 1, C_DATE_INSET_LIGHT);
  s.drawLine(DATE_X + DATE_W - 1, DATE_Y, DATE_X + DATE_W - 1, DATE_Y + DATE_H - 1, C_DATE_INSET_LIGHT);
}

// ─── СТРЕЛКИ ───
void drawHand(TFT_eSprite &s, float angleDeg, int length,
              int baseW, int tipW, uint16_t color, uint16_t hilite) {
  float a = (angleDeg - 90.0f) * DEG_TO_RAD;
  float ca = cosf(a), sa = sinf(a);
  int tipX = CX + (int)(ca * length), tipY = CY + (int)(sa * length);
  float perp = a + M_PI_2;
  float cP = cosf(perp), sP = sinf(perp);
  int bx1 = CX + (int)(cP * baseW), by1 = CY + (int)(sP * baseW);
  int bx2 = CX - (int)(cP * baseW), by2 = CY - (int)(sP * baseW);
  int tx1 = tipX + (int)(cP * tipW), ty1 = tipY + (int)(sP * tipW);
  int tx2 = tipX - (int)(cP * tipW), ty2 = tipY - (int)(sP * tipW);
  s.fillTriangle(tipX+2, tipY+2, bx1+2, by1+2, bx2+2, by2+2, C_SHADOW);
  s.fillTriangle(tipX+2, tipY+2, tx1+2, ty1+2, tx2+2, ty2+2, C_SHADOW);
  s.fillTriangle(tipX, tipY, bx1, by1, bx2, by2, color);
  s.fillTriangle(tipX, tipY, tx1, ty1, tx2, ty2, color);
  s.drawLine(bx1, by1, tipX, tipY, hilite);
}

void drawDateText(TFT_eSprite &s, int day) {
  if (day < 0) return;
  s.loadFont(FONT_DATE);
  s.setTextDatum(MC_DATUM);
  s.setTextColor(TFT_BLACK, TFT_WHITE);
  s.drawString(String(day), DATE_X + DATE_W/2, DATE_Y + DATE_H/2);
  s.unloadFont();
}

// ─── СТАТУС / ДАТА ───
void drawStatusText(TFT_eSprite &s, const struct tm* ti) {
  char buf[48];
  const char* msg = nullptr;

  if (phase == PHASE_RUN || phase == PHASE_SPIN) {
    if (SHOW_DATE_IN_STATUS && ti) {
      const char* wd = (ti->tm_wday >= 0 && ti->tm_wday < 7) ? WEEKDAYS_RU[ti->tm_wday] : "";
      snprintf(buf, sizeof(buf), "%02d-%02d-%04d, %s",
               ti->tm_mday, ti->tm_mon + 1, ti->tm_year + 1900, wd);
      msg = buf;
    } else return;
  } else {
    switch (phase) {
      case PHASE_WIFI:     msg = "Подключение к Wi-Fi";    break;
      case PHASE_SYNC:     msg = "Синхронизация времени";  break;
      case PHASE_NTP_FAIL: msg = "Ошибка синхронизации";   break;
      default: return;
    }
  }

  s.loadFont(FONT_STATUS);
  s.setTextDatum(BC_DATUM);
  if (INFO_SHADOW_ENABLED) {
    s.setTextColor(C_SHADOW, C_STATUS_BG);
    s.drawString(msg, INFO_X + INFO_SHADOW_DX, STATUS_Y + INFO_SHADOW_DY);
  }
  s.setTextColor(C_STATUS, C_STATUS_BG);
  s.drawString(msg, INFO_X, STATUS_Y);
  s.unloadFont();
}

// ─── ПОГОДА ───
bool fetchWeather() {
  if (WiFi.status() != WL_CONNECTED) return false;
  String url = "http://api.openweathermap.org/data/2.5/weather?q=";
  url += OWM_CITY; url += "&appid="; url += OWM_API_KEY;
  url += "&units=metric&lang=ru";
  HTTPClient http; http.begin(url);
  int code = http.GET();
  if (code != 200) { Serial.printf("Weather HTTP %d\n", code); http.end(); return false; }
  String payload = http.getString(); http.end();
  StaticJsonDocument<1536> doc;
  DeserializationError err = deserializeJson(doc, payload);
  if (err) { Serial.print("Weather JSON error: "); Serial.println(err.c_str()); return false; }
  g_tempC = doc["main"]["temp"] | 0.0f;
  const char* desc = doc["weather"][0]["description"] | "";
  strncpy(g_weatherDesc, desc, sizeof(g_weatherDesc) - 1);
  g_weatherDesc[sizeof(g_weatherDesc) - 1] = '\0';
  g_sunriseUnix = (time_t)(doc["sys"]["sunrise"] | 0L);
  g_sunsetUnix  = (time_t)(doc["sys"]["sunset"]  | 0L);
  g_sunValid    = (g_sunriseUnix > 0 && g_sunsetUnix > 0);
  Serial.printf("Weather: %.1f°C, %s; sun rise=%ld set=%ld\n",
                g_tempC, g_weatherDesc,
                (long)g_sunriseUnix, (long)g_sunsetUnix);
  return true;
}

// ─── КУРСЫ ───
bool fetchFxRates() {
  if (WiFi.status() != WL_CONNECTED) return false;
  String url = "https://v6.exchangerate-api.com/v6/";
  url += FX_API_KEY; url += "/latest/"; url += FX_BASE;
  HTTPClient http; http.begin(url);
  int code = http.GET();
  if (code != 200) { Serial.printf("FX HTTP %d\n", code); http.end(); return false; }
  String payload = http.getString(); http.end();
  StaticJsonDocument<4096> doc;
  DeserializationError err = deserializeJson(doc, payload);
  if (err) { Serial.print("FX JSON error: "); Serial.println(err.c_str()); return false; }
  if (String(doc["result"] | "") != "success") { Serial.println("FX: non-success"); return false; }
  float usd_per_rub = doc["conversion_rates"][FX_TARGET1] | 0.0f;
  float eur_per_rub = doc["conversion_rates"][FX_TARGET2] | 0.0f;
  g_usdRub = (usd_per_rub > 0.0f) ? (1.0f / usd_per_rub) : 0.0f;
  g_eurRub = (eur_per_rub > 0.0f) ? (1.0f / eur_per_rub) : 0.0f;
  Serial.printf("FX: %s=%.2f  %s=%.2f\n", FX_TARGET1, g_usdRub, FX_TARGET2, g_eurRub);
  return true;
}

// ─── СТРОКИ ───
void drawWeatherLine(TFT_eSprite &s) {
  if (!g_weatherValid) return;
  char buf[48];
  snprintf(buf, sizeof(buf), "%.0f°C %s", g_tempC, g_weatherDesc);
  s.loadFont(FONT_INFO);
  s.setTextDatum(BC_DATUM);
  if (INFO_SHADOW_ENABLED) {
    s.setTextColor(C_SHADOW, C_INFO_BG);
    s.drawString(buf, INFO_X + INFO_SHADOW_DX, WEATHER_Y + INFO_SHADOW_DY);
  }
  s.setTextColor(C_INFO, C_INFO_BG);
  s.drawString(buf, INFO_X, WEATHER_Y);
  s.unloadFont();
}

void drawFxLine(TFT_eSprite &s) {
  if (!g_fxValid) return;
  if (g_usdRub <= 0.0f && g_eurRub <= 0.0f) return;
  char buf[48];
  snprintf(buf, sizeof(buf), "$%.2f  €%.2f", g_usdRub, g_eurRub);
  s.loadFont(FONT_INFO);
  s.setTextDatum(BC_DATUM);
  if (INFO_SHADOW_ENABLED) {
    s.setTextColor(C_SHADOW, C_INFO_BG);
    s.drawString(buf, INFO_X + INFO_SHADOW_DX, FX_Y + INFO_SHADOW_DY);
  }
  s.setTextColor(C_INFO, C_INFO_BG);
  s.drawString(buf, INFO_X, FX_Y);
  s.unloadFont();
}

void drawSunLine(TFT_eSprite &s) {
  if (!g_sunValid) return;
  time_t now = time(nullptr);
  time_t eventUnix;
  const char* label;
  if (now < g_sunriseUnix) {
    eventUnix = g_sunriseUnix;  label = "Всх";
  } else if (now < g_sunsetUnix) {
    eventUnix = g_sunsetUnix;   label = "Зхд";
  } else {
    eventUnix = g_sunriseUnix + 86400;
    label     = "Всх";
  }
  struct tm et;
  localtime_r(&eventUnix, &et);
  char buf[32];
  snprintf(buf, sizeof(buf), "%s %02d:%02d", label, et.tm_hour, et.tm_min);
  s.loadFont(FONT_INFO);
  s.setTextDatum(BC_DATUM);
  if (INFO_SHADOW_ENABLED) {
    s.setTextColor(C_SHADOW, C_INFO_BG);
    s.drawString(buf, INFO_X + INFO_SHADOW_DX, SUN_Y + INFO_SHADOW_DY);
  }
  s.setTextColor(C_INFO, C_INFO_BG);
  s.drawString(buf, INFO_X, SUN_Y);
  s.unloadFont();
}

void drawHub(TFT_eSprite &s) {
  s.fillCircle(CX, CY, 5, C_HAND_DARK);
  s.fillCircle(CX, CY, 3, C_HAND_RED);
  if (HUB_HIGHLIGHT_ENABLED)
    s.fillCircle(CX + HUB_HL_DX, CY + HUB_HL_DY, HUB_HL_R, C_HAND_HILITE);
}

// ─── ЛУНА ───
static float moonPhase(time_t t) {
  const time_t NEW_MOON_REF = 947182440;
  const float  SYNODIC       = 29.530588853f;
  double days = (double)(t - NEW_MOON_REF) / 86400.0;
  double phase = fmod(days / SYNODIC, 1.0);
  if (phase < 0) phase += 1.0;
  return (float)phase;
}

void drawMoonIcon(TFT_eSprite &s, float phase, float pulse) {
  if (!MOON_ENABLED) return;
  int cx = CX - MOON_DIST_FROM_CENTER;
  int cy = CY;
  int r  = MOON_ICON_SIZE / 2;

  s.fillCircle(cx + MOON_SHADOW_DX, cy + MOON_SHADOW_DY, r, C_MOON_SHADOW);

  if (pulse > 0.15f) {
    uint8_t gv = (uint8_t)((pulse - 0.15f) / 0.85f * 180.0f);
    uint16_t glow1 = tft.color565(gv / 3, gv / 3, gv / 2);
    s.drawCircle(cx, cy, r + 1, glow1);
  }
  if (pulse > 0.55f) {
    uint8_t gv = (uint8_t)((pulse - 0.55f) / 0.45f * 140.0f);
    uint16_t glow2 = tft.color565(gv / 4, gv / 4, gv / 3);
    s.drawCircle(cx, cy, r + 2, glow2);
  }

  s.fillCircle(cx, cy, r, C_MOON_BASE);

  float phaseAngle = 2.0f * PI * phase;
  float cosPhase   = cosf(phaseAngle);
  bool  waxing     = (phase < 0.5f);
  float x_t_eq = waxing ? ((float)r * cosPhase) : (-(float)r * cosPhase);

  for (int dy = -r; dy <= r; dy++) {
    int xFull = (int)sqrtf((float)(r*r - dy*dy));
    if (xFull <= 0) continue;
    int x_t = (int)(x_t_eq * (float)xFull / (float)r);
    if (waxing) {
      int xStart = -xFull, xEnd = x_t;
      if (xEnd > xStart)
        s.drawFastHLine(cx + xStart, cy + dy, xEnd - xStart, C_MOON_DARK);
    } else {
      int xStart = x_t + 1, xEnd = xFull + 1;
      if (xEnd > xStart)
        s.drawFastHLine(cx + xStart, cy + dy, xEnd - xStart, C_MOON_DARK);
    }
  }

  struct { int dx, dy; bool big; } craters[] = {
    { -3, -2, false }, {  1, -4, false }, {  3,  1, true  },
    { -1,  3, false }, {  4, -3, false },
  };
  for (auto &c : craters) {
    int px = cx + c.dx, py = cy + c.dy;
    if (c.big) s.fillCircle(px, py, 1, C_MOON_CRATER);
    else       s.drawPixel(px, py, C_MOON_CRATER);
  }

  int hlx = waxing ? (cx + 3) : (cx - 3);
  int hly = cy - 3;
  int twinkleR = (int)(pulse * 2.5f);

  if (twinkleR >= 1) {
    s.drawFastHLine(hlx - twinkleR, hly, twinkleR * 2 + 1, C_MOON_HIGHLIGHT);
    s.drawFastVLine(hlx, hly - twinkleR, twinkleR * 2 + 1, C_MOON_HIGHLIGHT);
  }
  s.fillCircle(hlx, hly, twinkleR >= 1 ? 1 : 0, C_MOON_HIGHLIGHT);
  s.drawPixel(hlx, hly, tft.color565(255, 255, 255));

  if (pulse > 0.7f) {
    uint16_t sparkGlow = tft.color565(255, 230, 140);
    s.drawPixel(hlx - twinkleR - 1, hly, sparkGlow);
    s.drawPixel(hlx + twinkleR + 1, hly, sparkGlow);
    s.drawPixel(hlx, hly - twinkleR - 1, sparkGlow);
    s.drawPixel(hlx, hly + twinkleR + 1, sparkGlow);
  }
}

// ─────────────────────────────────────────────
// ПРИМЕНИТЬ ТЕМУ
// ─────────────────────────────────────────────
void applyTheme(int idx) {
  g_currentTheme = ((idx % THEME_COUNT) + THEME_COUNT) % THEME_COUNT;
  const Theme& th = THEMES[g_currentTheme];

  g_gradCR = th.gradCR; g_gradCG = th.gradCG; g_gradCB = th.gradCB;
  g_gradER = th.gradER; g_gradEG = th.gradEG; g_gradEB = th.gradEB;

  C_RING     = tft.color565(th.ringR, th.ringG, th.ringB);
  C_TICK_MIN = tft.color565(th.tickR, th.tickG, th.tickB);

  // Цвет «дна» под VLW-текстом в инфо-области = цвет градиента в этой точке
  C_STATUS_BG = gradientColorAt(CX, STATUS_Y);
  C_INFO_BG   = gradientColorAt(CX, FX_Y);

  // Перерисовка статичного фона
  bgSpr.fillSprite(TFT_BLACK);
  drawGradientDithered(bgSpr);
  drawTicks(bgSpr);
  drawRing(bgSpr);
  drawNumbers(bgSpr);
  drawTitle(bgSpr);
  drawDateFrame(bgSpr);

  Serial.printf("Theme applied: %s\n", th.name);
}

// ─── КАДР ───
void renderFrame(float aH, float aM, float aS, const struct tm* ti) {
  memcpy(workSpr.getPointer(), bgSpr.getPointer(), SPR_BYTES);

  int day = ti ? ti->tm_mday : -1;
  drawDateText(workSpr, day);
  drawStatusText(workSpr, ti);
  drawWeatherLine(workSpr);
  drawFxLine(workSpr);
  drawSunLine(workSpr);

  if (ti) {
    float phase = moonPhase(time(nullptr));
    float t = (float)(millis() % MOON_PULSE_MS) / (float)MOON_PULSE_MS;
    float pulse = 0.5f - 0.5f * cosf(t * 2.0f * PI);
    drawMoonIcon(workSpr, phase, pulse);
  }

  drawHand(workSpr, aH, 55, 6, 3, C_HAND_RED,  C_HAND_HILITE);
  drawHand(workSpr, aM, 80, 5, 2, C_HAND_RED,  C_HAND_HILITE);
  drawHand(workSpr, aS, 92, 3, 1, C_HAND_DARK, C_HAND_HILITE);

  drawHub(workSpr);
  workSpr.pushSprite(0, 0);
}

// ─── SETUP ───
void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("\nOlyaClock v15 starting...");

  pinMode(BTN_BOOT_PIN, INPUT_PULLUP);

  tft.init();
  tft.setRotation(0);
  tft.fillScreen(TFT_BLACK);

  initColors();

  bgSpr.setColorDepth(8);
  workSpr.setColorDepth(8);
  if (!bgSpr.createSprite(SCR_W, SCR_H) || !workSpr.createSprite(SCR_W, SCR_H)) {
    Serial.println("FATAL: sprite allocation failed");
    while (true) delay(1000);
  }
  Serial.printf("Sprites OK, free heap: %u\n", ESP.getFreeHeap());

  applyTheme(0);   // тема по умолчанию — синяя

  phase      = PHASE_WIFI;
  phaseStart = millis();

  renderFrame(angleHour(DEFAULT_HOUR, DEFAULT_MIN, 0, 0),
              angleMin(DEFAULT_MIN, 0, 0), 0, nullptr);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.println("WiFi started (non-blocking)");
}

// ─── LOOP ───
void loop() {
  static unsigned long lastFrame = 0;
  unsigned long now = millis();
  if (now - lastFrame < 40) return;
  lastFrame = now;

  // ─── Кнопка BOOT: смена темы ───
  static int  lastBtnState = HIGH;
  static unsigned long lastPressMs = 0;
  int btnState = digitalRead(BTN_BOOT_PIN);
  if (btnState == LOW && lastBtnState == HIGH
      && now - lastPressMs > BTN_DEBOUNCE_MS) {
    applyTheme(g_currentTheme + 1);
    lastPressMs = now;
  }
  lastBtnState = btnState;

  switch (phase) {
    case PHASE_WIFI:
      if (WiFi.status() == WL_CONNECTED) {
        Serial.println("WiFi OK -> SYNC");
        phase = PHASE_SYNC; phaseStart = now;
        configTzTime(TZ_INFO, NTP_SERVER);
      } else if (now - phaseStart > WIFI_TIMEOUT_MS) {
        Serial.println("WiFi timeout, retry");
        WiFi.disconnect(); WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
        phaseStart = now;
      }
      break;
    case PHASE_SYNC:
      if (timeIsValid()) {
        Serial.println("NTP OK -> SPIN");
        spinStart = now;
        spinStartH = angleHour(DEFAULT_HOUR, DEFAULT_MIN, 0, 0);
        spinStartM = angleMin(DEFAULT_MIN, 0, 0);
        spinStartS = 0;
        phase = PHASE_SPIN;
      } else if (now - phaseStart > NTP_TIMEOUT_MS) {
        phase = PHASE_NTP_FAIL; phaseStart = now;
      }
      break;
    case PHASE_NTP_FAIL:
      if (timeIsValid()) {
        spinStart = now;
        spinStartH = angleHour(DEFAULT_HOUR, DEFAULT_MIN, 0, 0);
        spinStartM = angleMin(DEFAULT_MIN, 0, 0);
        spinStartS = 0;
        phase = PHASE_SPIN;
      } else if (WiFi.status() != WL_CONNECTED) {
        phase = PHASE_WIFI; phaseStart = now; WiFi.reconnect();
      }
      break;
    case PHASE_SPIN:
      if (now - spinStart > SPIN_DURATION_MS) phase = PHASE_RUN;
      break;
    case PHASE_RUN:
      if (WiFi.status() != WL_CONNECTED) {
        WiFi.reconnect(); phase = PHASE_WIFI; phaseStart = now;
      }
      break;
  }

  if (phase == PHASE_RUN) {
    if (now - g_lastWeatherMs > WEATHER_UPDATE_MS || !g_weatherValid) {
      if (fetchWeather()) g_weatherValid = true;
      g_lastWeatherMs = now;
    }
    if (now - g_lastFxMs > FX_UPDATE_MS || !g_fxValid) {
      if (fetchFxRates()) g_fxValid = true;
      g_lastFxMs = now;
    }
  }

  if (phase == PHASE_RUN) {
    struct timeval tv; gettimeofday(&tv, nullptr);
    struct tm ti; localtime_r(&tv.tv_sec, &ti);
    float sub = tv.tv_usec / 1000000.0f;
    renderFrame(angleHour(ti.tm_hour, ti.tm_min, ti.tm_sec, sub),
                angleMin(ti.tm_min, ti.tm_sec, sub),
                angleSec(ti.tm_sec, sub), &ti);
    return;
  }

  if (phase == PHASE_SPIN) {
    float p = (now - spinStart) / (float)SPIN_DURATION_MS;
    struct timeval tv; gettimeofday(&tv, nullptr);
    struct tm ti; localtime_r(&tv.tv_sec, &ti);
    float sub = tv.tv_usec / 1000000.0f;
    float tH = angleHour(ti.tm_hour, ti.tm_min, ti.tm_sec, sub);
    float tM = angleMin(ti.tm_min, ti.tm_sec, sub);
    float tS = angleSec(ti.tm_sec, sub);
    float ease = 1.0f - powf(1.0f - p, 3.0f);
    renderFrame(spinStartH + ease * ((tH - spinStartH) + 360.0f * SPIN_HOUR_TURNS),
                spinStartM + ease * ((tM - spinStartM) + 360.0f * SPIN_MIN_TURNS),
                spinStartS + ease * ((tS - spinStartS) + 360.0f * SPIN_SEC_TURNS),
                &ti);
    return;
  }

  renderFrame(angleHour(DEFAULT_HOUR, DEFAULT_MIN, 0, 0),
              angleMin(DEFAULT_MIN, 0, 0), 0, nullptr);
}